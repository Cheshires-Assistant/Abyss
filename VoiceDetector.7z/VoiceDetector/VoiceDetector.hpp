/** Author:       Plyashkevich Viatcheslav <plyashkevich@yandex.ru> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library or "Lesser" General Public License version 3.0 (LGPLv3)
 * All rights reserved. 
 */


#if _SPEECH_DETECTOR_ == 0
#define _SPEECH_DETECTOR_ 1

class VoiceDetector
{   
	static const unsigned FOURIE_COEFF = 64;
	static const unsigned TIME_DURATION = 16;
   
    static union Wu
    {
		const short w[2 * FOURIE_COEFF];
		const double y[16];      
    } wu; 
    
    union Inner
	{
		int inp[FOURIE_COEFF * 2];
		int inr[FOURIE_COEFF * 2];
                double y[16];
		Inner(){}
	} inner, input;    

    int countSpeechDetection;

	short storePrevious[FOURIE_COEFF << 1];

	void fft16x32(const short * ptr_w, int npoints, int * ptr_x, int * ptr_y);

	int voiceProcessing(short ptr_x[FOURIE_COEFF * 2]);

  public:
    
	// It method return true, if human speech detecting.
    bool voiceDetection(short *in  //in is 8 KHz, 16 bits PCM in array, which size is 128 samples.
	);

	const short * getData() const
	{
		return storePrevious;
	}

    VoiceDetector(): countSpeechDetection(0) 
    {
		for(int ii = 0; ii < FOURIE_COEFF << 1; ++ii)
			storePrevious[ii] = 0;
    }

    ~VoiceDetector() {}
};

#endif




