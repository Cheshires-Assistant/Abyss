 /** Author:       Plyashkevich Viatcheslav <plyashkevich@yandex.ru> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library or "Lesser" General Public License version 3.0 (LGPLv3)
 * All rights reserved. 
 */


#include "VoiceDetector.hpp"
#include <stdio.h>

#define NUMBER 128
short in[NUMBER], out[NUMBER];

VoiceDetector voiceDetector;

FILE *file1, *file2;

int main(char *argv[])
{  
	// In file - 8 KHz, 16 bits PCM samples,  may include human speech, tones or noise
	file1 = fopen(argv[1], "r+b"); 
	// Out file - 8 KHz, 16 bits PCM samples, included just human speech
	file2 = fopen(argv[2], "w+b");
	
	while(true)
	{    
	  	if(fread(in, sizeof(short), NUMBER, file1) != 128)
			break;     
		// If human speech detect, so voiceDetection method return true, and writing will be used in out file
	 	if(voiceDetector.voiceDetection(in))
		{
			fwrite(voiceDetector.getData(), sizeof(short), NUMBER, file2);
		}		
	}
	fclose(file1);
	fclose(file2);
	return 0;
}

